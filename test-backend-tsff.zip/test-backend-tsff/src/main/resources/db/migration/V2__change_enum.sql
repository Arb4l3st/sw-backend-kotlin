UPDATE budget SET type = 'Расход'
WHERE type = 'Комиссия'