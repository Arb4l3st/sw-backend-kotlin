ALTER TABLE budget
ADD author int