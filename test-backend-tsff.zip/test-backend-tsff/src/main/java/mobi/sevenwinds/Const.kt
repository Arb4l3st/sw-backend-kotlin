package mobi.sevenwinds

object Const {
    const val jwtAuth = "auth-jwt"

    const val version = "0.10.8"
}